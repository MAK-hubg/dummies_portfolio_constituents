library(testthat)
library(PortfolioConstituents)

test_check("PortfolioConstituents")
